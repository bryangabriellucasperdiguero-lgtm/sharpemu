// Copyright (C) 2026 SharpEmu Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

using System.Globalization;
using System.IO;
using System.Text;

namespace SharpEmu.Logging;

public sealed class FileLogSink : ISharpEmuLogSink, IDisposable
{
    private static readonly TimeSpan FlushInterval = TimeSpan.FromMilliseconds(500);
    private const string TimestampFormat = "yyyy-MM-dd HH:mm:ss.fff";
    private const int TimestampBufferLength = 32;

    private readonly object _sync = new();
    private readonly StreamWriter _writer;
    private readonly Timer _flushTimer;
    private bool _disposed;

    public FileLogSink(string path, bool append = true, bool includeTimestamp = true)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(path);

        var directory = Path.GetDirectoryName(path);
        if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
        {
            Directory.CreateDirectory(directory);
        }

        var fileStream = new FileStream(
            path,
            append ? FileMode.Append : FileMode.Create,
            FileAccess.Write,
            FileShare.Read,
            bufferSize: 65536,
            FileOptions.SequentialScan);
        _writer = new StreamWriter(fileStream, Encoding.UTF8, bufferSize: 65536)
        {
            AutoFlush = false
        };

        IncludeTimestamp = includeTimestamp;

        _flushTimer = new Timer(
            static state => ((FileLogSink)state!).FlushBuffered(),
            this,
            FlushInterval,
            FlushInterval);
    }

    public bool IncludeTimestamp { get; set; }

    public void Write(in LogEntry entry)
    {
        lock (_sync)
        {
            if (_disposed)
            {
                return;
            }

            if (IncludeTimestamp)
            {
                // Formatted into a stack buffer with the invariant culture: no
                // per-line string allocation, and '-' / ':' stay literal on every
                // locale (custom-format separators are culture-dependent).
                Span<char> stamp = stackalloc char[TimestampBufferLength];
                _writer.Write('[');
                if (entry.Timestamp.TryFormat(stamp, out var written, TimestampFormat, CultureInfo.InvariantCulture))
                {
                    _writer.Write(stamp[..written]);
                }
                else
                {
                    _writer.Write(entry.Timestamp.ToString(TimestampFormat, CultureInfo.InvariantCulture));
                }

                _writer.Write(']');
            }

            _writer.Write('[');
            _writer.Write(ToLevelLabel(entry.Level));
            _writer.Write(']');
            _writer.Write('[');
            _writer.Write(entry.Category);
            _writer.Write(']');
            _writer.Write(' ');

            _writer.Write(entry.SourceFileName);
            if (entry.SourceLine > 0)
            {
                _writer.Write(':');
                _writer.Write(entry.SourceLine);
            }

            _writer.Write(' ');
            _writer.WriteLine(entry.Message);

            if (entry.Exception is not null)
            {
                _writer.WriteLine(entry.Exception);
            }

            if (entry.Level >= LogLevel.Error)
            {
                _writer.Flush();
            }
        }
    }

    private void FlushBuffered()
    {
        lock (_sync)
        {
            if (_disposed)
            {
                return;
            }

            _writer.Flush();
        }
    }

    public void Dispose()
    {
        _flushTimer.Dispose();

        lock (_sync)
        {
            if (_disposed)
            {
                return;
            }

            _disposed = true;
            _writer.Flush();
            _writer.Dispose();
        }
    }

    private static string ToLevelLabel(LogLevel level) => level switch
    {
        LogLevel.Trace => "TRACE",
        LogLevel.Debug => "DEBUG",
        LogLevel.Info => "INFO",
        LogLevel.Warning => "WARNING",
        LogLevel.Error => "ERROR",
        LogLevel.Critical => "CRITICAL",
        _ => "LOG",
    };
}
