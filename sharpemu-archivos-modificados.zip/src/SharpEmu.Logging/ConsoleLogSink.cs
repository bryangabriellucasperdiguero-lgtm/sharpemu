// Copyright (C) 2026 SharpEmu Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

using System.Buffers;
using System.Globalization;
using System.IO;
using System.Text;

namespace SharpEmu.Logging;

public sealed class ConsoleLogSink : ISharpEmuLogSink
{
    // Console.Out / Console.Error are auto-flushed: every Write call is its own
    // write(2)/WriteFile. A log line is therefore assembled off-lock into a
    // reusable per-thread buffer and emitted with as few Write calls as
    // possible (one when colours are off) instead of ~12 tiny ones.
    private const int MaxRetainedBuilderCapacity = 16 * 1024;

    // Any of these (case-insensitive) is a prerequisite for a coloured message.
    // One vectorised multi-string search rejects the overwhelming majority of
    // messages instead of running up to 11 separate IndexOf scans over them.
    private static readonly SearchValues<string> ColorTriggers = SearchValues.Create(
        [
            "unresolved import",
            "unresolved symbol",
            "hot_unresolved_imports=",
            "unresolved_imports_hit=",
            "syscall",
            "Import trace",
            "import_stub_return",
            "last_import=",
            "hot_imports=",
            "resolved import",
        ],
        StringComparison.OrdinalIgnoreCase);

    [ThreadStatic]
    private static StringBuilder? _lineBuilder;

    private readonly object _sync = new();

    public ConsoleLogSink(bool useColors = true, bool includeTimestamp = false)
    {
        UseColors = useColors;
        IncludeTimestamp = includeTimestamp;
    }

    public bool UseColors { get; set; }

    public bool IncludeTimestamp { get; set; }

    public void Write(in LogEntry entry)
    {
        var useColors = UseColors;
        var level = entry.Level;
        var message = entry.Message;
        var writer = level >= LogLevel.Error ? Console.Error : Console.Out;

        var builder = _lineBuilder ??= new StringBuilder(512);
        builder.Clear();

        if (!useColors)
        {
            // Plain output: the whole line, newline and exception included, in one write.
            if (IncludeTimestamp)
            {
                AppendTimestamp(builder, entry);
            }

            builder.Append(ToLevelSegment(level));
            AppendSourcePrefix(builder, entry);
            builder.Append(message);
            AppendTail(builder, entry.Exception);

            var length = builder.Length;
            var buffer = ArrayPool<char>.Shared.Rent(length);
            try
            {
                builder.CopyTo(0, buffer, 0, length);
                Recycle(builder);
                lock (_sync)
                {
                    writer.Write(new ReadOnlySpan<char>(buffer, 0, length));
                }
            }
            finally
            {
                ArrayPool<char>.Shared.Return(buffer);
            }

            return;
        }

        string? timestamp = null;
        if (IncludeTimestamp)
        {
            AppendTimestamp(builder, entry);
            timestamp = builder.ToString();
            builder.Clear();
        }

        var colorMessage = TryGetMessageColor(message, out var messageColor);
        AppendSourcePrefix(builder, entry);
        if (!colorMessage)
        {
            builder.Append(message);
            AppendTail(builder, entry.Exception);
        }

        var restLength = builder.Length;
        var rest = ArrayPool<char>.Shared.Rent(restLength);
        try
        {
            builder.CopyTo(0, rest, 0, restLength);
            Recycle(builder);
            var tail = colorMessage ? BuildTail(entry.Exception) : null;

            lock (_sync)
            {
                if (timestamp is not null)
                {
                    writer.Write(timestamp);
                }

                var originalColor = Console.ForegroundColor;
                Console.ForegroundColor = GetLevelColor(level);
                writer.Write(ToLevelSegment(level));
                Console.ForegroundColor = originalColor;

                writer.Write(new ReadOnlySpan<char>(rest, 0, restLength));
                if (colorMessage)
                {
                    originalColor = Console.ForegroundColor;
                    Console.ForegroundColor = messageColor;
                    writer.Write(message);
                    Console.ForegroundColor = originalColor;
                    writer.Write(tail);
                }
            }
        }
        finally
        {
            ArrayPool<char>.Shared.Return(rest);
        }
    }

    private static void AppendTimestamp(StringBuilder builder, in LogEntry entry)
    {
        // Invariant culture: ':' in a custom format is the culture's time
        // separator, which is not ':' everywhere.
        builder.Append('[')
            .Append(CultureInfo.InvariantCulture, $"{entry.Timestamp:HH:mm:ss.fff}")
            .Append(']');
    }

    // "[Category] File:Line " — everything between the level tag and the message.
    private static void AppendSourcePrefix(StringBuilder builder, in LogEntry entry)
    {
        builder.Append('[').Append(entry.Category).Append("] ").Append(entry.SourceFileName);
        if (entry.SourceLine > 0)
        {
            builder.Append(':').Append(entry.SourceLine);
        }

        builder.Append(' ');
    }

    private static void AppendTail(StringBuilder builder, Exception? exception)
    {
        builder.Append(Environment.NewLine);
        if (exception is not null)
        {
            builder.Append(exception.ToString()).Append(Environment.NewLine);
        }
    }

    private static string BuildTail(Exception? exception)
        => exception is null
            ? Environment.NewLine
            : string.Concat(Environment.NewLine, exception.ToString(), Environment.NewLine);

    private static void Recycle(StringBuilder builder)
    {
        // A single huge message must not pin a huge buffer to the thread forever.
        if (builder.Capacity > MaxRetainedBuilderCapacity)
        {
            _lineBuilder = null;
        }
    }

    private static string ToLevelSegment(LogLevel level)
    {
        return level switch
        {
            LogLevel.Trace => "[TRACE]",
            LogLevel.Debug => "[DEBUG]",
            LogLevel.Info => "[INFO]",
            LogLevel.Warning => "[WARNING]",
            LogLevel.Error => "[ERROR]",
            LogLevel.Critical => "[CRITICAL]",
            _ => "[LOG]",
        };
    }

    private static ConsoleColor GetLevelColor(LogLevel level)
    {
        return level switch
        {
            LogLevel.Trace => ConsoleColor.DarkGray,
            LogLevel.Debug => ConsoleColor.Gray,
            LogLevel.Info => ConsoleColor.Blue,
            LogLevel.Warning => ConsoleColor.Yellow,
            LogLevel.Error => ConsoleColor.Red,
            LogLevel.Critical => ConsoleColor.DarkRed,
            _ => ConsoleColor.White,
        };
    }

    private static bool TryGetMessageColor(string message, out ConsoleColor color)
    {
        if (string.IsNullOrWhiteSpace(message) ||
            !message.AsSpan().ContainsAny(ColorTriggers))
        {
            color = default;
            return false;
        }

        if (ContainsIgnoreCase(message, "unresolved import") ||
            ContainsIgnoreCase(message, "unresolved symbol") ||
            ContainsIgnoreCase(message, "hot_unresolved_imports=") ||
            ContainsIgnoreCase(message, "unresolved_imports_hit="))
        {
            color = ConsoleColor.Red;
            return true;
        }

        if (ContainsIgnoreCase(message, "syscall") ||
            ContainsIgnoreCase(message, "UnhandledSyscall"))
        {
            color = ConsoleColor.DarkYellow;
            return true;
        }

        if (ContainsIgnoreCase(message, "Import trace") ||
            ContainsIgnoreCase(message, "import_stub_return") ||
            ContainsIgnoreCase(message, "last_import=") ||
            ContainsIgnoreCase(message, "hot_imports=") ||
            ContainsIgnoreCase(message, "resolved import"))
        {
            color = ConsoleColor.Blue;
            return true;
        }

        color = default;
        return false;
    }

    private static bool ContainsIgnoreCase(string text, string value)
    {
        return text.IndexOf(value, StringComparison.OrdinalIgnoreCase) >= 0;
    }
}
